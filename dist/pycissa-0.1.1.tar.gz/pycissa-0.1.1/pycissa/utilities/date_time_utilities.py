import numpy as np
import datetime
import calendar
month_days = {1:31,   #days in each month
              2:28,
              3:31,
              4:30,
              5:31,
              6:30,
              7:31,
              8:31,
              9:30,
              10:31,
              11:30,
              12:31}

# mydate = mydate.replace(day=mydate.day+1)

# from dateutil.relativedelta import relativedelta
# mydate + relativedelta(days=31)